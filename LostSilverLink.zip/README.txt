This is a remaster and continuation of the classic GameMode for Pokémon 3D 0.60+, based on the famous Pokémon Lost Silver creepypasta and the fangames by Reidd Maxwell.

[Installation Instructions]
1.	Download the LostSilver.zip file from https://github.com/JappaWakka/LostSilver3DRemastered/releases/tag/latest

2.	Open the .zip file using Winrar or 7Zip and extract the "GameModes" and "Save" folder
	into the directory where you've installed Pokémon 3D, overwriting the existing folders.
	
3.	Be sure that there are no ContentPacks active while playing through this GameMode.

4.	Then, start the game and load the save file with "..." as the player name.

5.	Have fun and be careful not to get too spooked!

- @jappawakka on Discord

Credits:

Nilllzz - Creator of the classic GameMode, originally for v0.28 (https://forum.pokemon3d.net/resources/21/)
JappaWakka - Lead Developer of the remastered and expanded GameMode
AlexCorruptor - Mapmaker, bugtester, incredible emotional support and impressively motivating friend